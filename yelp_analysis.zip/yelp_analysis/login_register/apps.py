from django.apps import AppConfig


class LoginRegisterConfig(AppConfig):
    name = 'login_register'
